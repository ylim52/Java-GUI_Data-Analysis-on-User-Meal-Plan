README

Food Query and Meal Analysis

Name: Sukyoung Cho (scho83@wisc.edu)
      YeEun Lim (ylim52@wisc.edu)
      Nahroo Yun (nyun@wisc.edu)
      YongSang Park (ypark272@wisc.edu)
	  
D-team 85

Instructions:

There are buttons and menus which allows users to navigate and utilize the functionalities of the program.
Most of them are intuitive and have detailed explanations which makes the program more user-friendly.
It facilitates users to create their own meals with functions such as adding foods to the meal list and 
filtering the list of foods based on the given conditions.